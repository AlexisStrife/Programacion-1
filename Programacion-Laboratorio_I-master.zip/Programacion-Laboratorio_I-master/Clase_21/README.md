# Clase 21

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Creacion_lista_dinamica.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=1C7nohjt0BU&index=21&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

 Tomar el ejercicio anterior y cambiar el array est�tico por uno din�mico usando malloc.

- Version: 0.1 del 09 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*   Uso de memoria din�mica. Creaci�n de una lista que crece en forma din�mica.